/**
 * it.uniroma1.sapy.parser contiene il parser di Sapy.
 */
package it.uniroma1.sapy.parser;
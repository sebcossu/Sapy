/**
 * it.uniroma1.sapy.data contiene i token, i nodi degli alberi binari e le librerie di funzioni statiche e non utilizzate da Sapy.
 */
package it.uniroma1.sapy.data;
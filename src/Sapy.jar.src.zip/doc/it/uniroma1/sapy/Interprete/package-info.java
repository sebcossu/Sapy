/**
 * it.uniroma1.sapy.interprete contiene l'interprete del progetto Sapy.
 */
package it.uniroma1.sapy.interprete;